./sugarmaker -a YespowerSugar -o stratum+tcp://1pool.sugarchain.org:3333 -u sugar1q524wu3efa0lkrxkjqfjhhdnl93gdfeg5e7vq0x -t1
