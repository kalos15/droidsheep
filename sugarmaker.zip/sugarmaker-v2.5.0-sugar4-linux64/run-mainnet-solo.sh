./sugarmaker -a YespowerSugar -o http://127.0.0.1:34229 -u RPCUSER -p RPCPASSWORD --coinbase-addr=sugar1q524wu3efa0lkrxkjqfjhhdnl93gdfeg5e7vq0x -t1
